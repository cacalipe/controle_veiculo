package com.projeto.feign;

import java.util.List;

public class ListTempData {

	private List<TempData> modelos;
	private List<TempData> anos;
	
	public List<TempData> getModelos() {
		return modelos;
	}
	public void setModelos(List<TempData> modelos) {
		this.modelos = modelos;
	}
	public List<TempData> getAnos() {
		return anos;
	}
	public void setAnos(List<TempData> anos) {
		this.anos = anos;
	}
	
	
}
