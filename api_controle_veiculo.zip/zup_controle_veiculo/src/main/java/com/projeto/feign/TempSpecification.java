package com.projeto.feign;

public class TempSpecification {

	public String Marca;
	public String Modelo;
	public int AnoModelo;
}
